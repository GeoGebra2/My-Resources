import numpy as np
import LP

## parameters of the standard form dual LP 
c =  
A =  
b =  

mu0 = np.array([4,1,2,3], dtype=float)

mu_traces = LP.barrier(-c, A, b, mu0)

print('')
for k,mu in enumerate(mu_traces):
	print('iteration %d: %s' % (k, mu))
print('dual optimal value:', c@mu_traces[-1])
